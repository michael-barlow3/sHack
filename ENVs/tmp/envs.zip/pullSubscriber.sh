sudo docker pull mwbarlow/subscriber_r2:latest
sudo docker image tag mwbarlow/subscriber_r2:latest subscriber_r2
sudo docker rmi mwbarlow/subscriber_r2:latest