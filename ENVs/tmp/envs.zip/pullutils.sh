sudo docker pull mwbarlow/utils:latest
sudo docker image tag mwbarlow/utils:latest utils
sudo docker rmi mwbarlow/utils:latest
