# Script to run all the different services and install the GUI for the VistA Audit Solution
./utils.sh
./metadata.sh
./subscriber.sh
./redshift.sh
./pushGUI.sh
