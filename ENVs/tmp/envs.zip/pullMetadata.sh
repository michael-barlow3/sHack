sudo docker pull mwbarlow/metadata_r2:latest
sudo docker image tag mwbarlow/metadata_r2:latest metadata_r2
sudo docker rmi mwbarlow/metadata_r2:latest