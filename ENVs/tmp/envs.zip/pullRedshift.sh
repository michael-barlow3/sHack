docker pull gefunk/redshift-node:latest
sudo docker image tag gefunk/redshift-node:latest redshift
sudo docker rmi gefunk/redshift-node:latest