sudo unzip vsr_gui.zip -d /var/www/vsr
sudo chmod 555 /var/www/vsr/index.html
sudo chmod 555 /var/www/vsr/assets -R
sudo chmod 555 /var/www/vsr/static -R

